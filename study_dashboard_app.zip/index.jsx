
export default function Dashboard() {
  return <div>Hello Study Dashboard</div>;
}
